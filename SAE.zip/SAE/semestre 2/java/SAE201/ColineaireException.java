
public class ColineaireException extends Exception{
    public ColineaireException(String msg) {
        super(msg);
    }
}